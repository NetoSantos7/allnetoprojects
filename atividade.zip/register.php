<?php
    include ('conexão.php');

$nome = $_POST['nome'];
$email = $_POST['email'];
$senha = $_POST['senha'];

$query = "INSERT INTO `usuarios`( `nome`, `email`, `senha`) VALUES ('$nome','$email','$senha')";

$resultado = mysqli_query($conn, $query);

if($resultado){
    echo "Registrado com Sucesso";
    
}
else{
    die("erro".mysqli_error($conn));
}
?>