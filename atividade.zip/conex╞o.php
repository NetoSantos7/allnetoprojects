<?php
$servename= "localhost";
$db_name= "registro_usuario";
$username= "root";
$password= "";
$conn = mysqli_connect($servename, $username, $password, $db_name);

        if(!$conn) {
    die("erro na conexão com o banco de dados:".mysqli_connect_error());
}
?>