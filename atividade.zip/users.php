<?php 
include ('conexão.php');
header('Content-type: application/json');
$sql = ("SELECT* FROM usuarios Where 1");
mysqli_set_charset($conn,'utf8');
$resultado= mysqli_query($conn, $sql);

if($conn->error){
    die('Erro na consulta' .$conn -> error);

}

    $data = array();
    while($row = $resultado-> fetch_assoc()
    ){
        $data[] = $row;
    }
    echo json_encode ($data);
    $conn-> close();
?>